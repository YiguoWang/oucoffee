
def print_hi():
	print('hi')

def print_hello():
	print('hello')

if __name__=='__main__':
	print_hi()